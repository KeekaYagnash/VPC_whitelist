import boto3
import json
import random
import string

def lambda_handler(event, context):
    # Set user ID as 
    # Extracting userID from the event (if available)
    user_id = event.get('user_id', 'unknown_user')

    s3_client = boto3.client('s3')
    # update the access to the vectors data that are incoming on the event
    data = event.get('key_value_pairs', {})
    # Update File name as required
    file_name = "vector_data_" + generate_random_string(6) + ".json"
    obj_file_path_s3_vector = f"{user_id}/{file_name}"
    s3_client.put_object(Body=json.dumps(data), Bucket='ai-shop-vector-file-store', Key=obj_file_path_s3_vector)
    
    # Send success message to sqs 
    sqs = boto3.client('sqs', region_name='af-south-1')
    queue_url = 'https://sqs.af-south-1.amazonaws.com/212546990317/Ai_Shop_Production_Success_Queue'
    message_body = json.dumps({'Message': 'Vectors Successfully Written.'})
    sqs.send_message(QueueUrl=queue_url, MessageBody=message_body)

    return {
        'statusCode': 200,
        'body': json.dumps('File written and uploaded to vectors-s3.')
    }

# Random characters generation
def generate_random_string(length):
    ran_char = string.ascii_letters + string.digits
    return ''.join(random.choice(ran_char) for _ in range(length))